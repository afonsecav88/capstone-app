## Proyecto final del curso Front-End Developer Capstone de Coursera. 

### Esta aplicación fue creada con React.
### Es el proyecto final de este curso, que es parte de la ruta para obtener el Certificado profesional de Meta Front-End Developer.

### Levantar la aplicación en desarrollo.

1. Para instalar dependencias de desarrollo ```npm install```
2. Para levantar el server de desarrollo ```npm start```
3. Para hacer el build de la app ```npm run build``` 