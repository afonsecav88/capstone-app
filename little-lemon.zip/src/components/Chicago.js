import React from 'react';

export const Chicago = () => {
  return (
    <section>
      <h1 id="section-chicago-h1">Little Lemon</h1>
      <h2 id="section-chicago-h2">Chicago</h2>
    </section>
  );
};
