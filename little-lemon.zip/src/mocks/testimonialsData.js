import person1 from '../images/person1.svg';
import person2 from '../images/person2.svg';
import person3 from '../images/person3.svg';
import person4 from '../images/person4.svg';

export const testimonialsData = [
  {
    id: '11aasadd',
    cover: person1,
    name: 'Person1 ',
    reviewText: `The famousus greek salad of crispy lettuce,peppers,olves and our
    Chicago style feta cheese,garnishe with crunchy garlic and rosemary
    crountons.`,
    reviewIcon: '4.9⭐',
  },
  {
    id: '11asdfffasadd',
    cover: person2,
    name: 'Person2',
    reviewText: `Our Bruchetta is made form grilled bread that has been smeared whith garlic and seasoned whith salt and olive oil.`,
    reviewIcon: '4.8⭐',
  },
  {
    id: 'fdgfdgd5566',
    cover: person3,
    name: 'Person3',
    reviewText: `This comes straight form grandma's recipe book, every last ingredient has been spurced and is authentic as can be imagined.`,
    reviewIcon: '4.5⭐',
  },
  {
    id: 'sdfsddssdfsfsfsd5555',
    cover: person4,
    name: 'Person4',
    reviewText: `Our Bruchetta is made form grilled bread that has been smeared whith garlic and seasoned whith salt and olive oil.`,
    reviewIcon: '5⭐',
  },
];
